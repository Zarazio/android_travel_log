package turn.zio.zara.travel_log;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

public class Map_TestActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map__test);
    }
}
